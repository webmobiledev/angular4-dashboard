import { IMenuItem } from './menu-item';
import { MENU } from '../../../../settings/menu';

export const MENUITEMS: IMenuItem[] = MENU;