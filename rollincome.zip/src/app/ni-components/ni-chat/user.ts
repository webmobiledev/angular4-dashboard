export interface User {
  name: string;
  lastSeen: string;
  avatar?: string;
}