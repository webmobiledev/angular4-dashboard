import { BgDirective } from './bg.directive';

describe('BgDirective', () => {
  it('should create an instance', () => {
    const directive = new BgDirective();
    expect(directive).toBeTruthy();
  });
});
