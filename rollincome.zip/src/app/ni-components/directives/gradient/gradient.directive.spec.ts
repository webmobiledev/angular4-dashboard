import { GradientDirective } from './gradient.directive';

describe('GradientDirective', () => {
  it('should create an instance', () => {
    const directive = new GradientDirective();
    expect(directive).toBeTruthy();
  });
});
