import { AutoGrowDirective } from './auto-grow.directive';

describe('AutoGrowDirective', () => {
  it('should create an instance', () => {
    const directive = new AutoGrowDirective();
    expect(directive).toBeTruthy();
  });
});
